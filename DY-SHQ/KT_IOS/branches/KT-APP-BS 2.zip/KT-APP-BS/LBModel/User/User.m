//
//  User.m
//  APP-BS-MODEL
//
//  Created by admin on 15/6/4.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import "User.h"

@implementation User

@end
