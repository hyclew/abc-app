//
//  SetCell.h
//  民生小区
//
//  Created by 闫青青 on 15/4/21.
//  Copyright (c) 2015年 闫青青. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;


@end
