//
//  WaitPayment.h
//  民生小区
//
//  Created by 闫青青 on 15/5/18.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaitPayment : UITableViewController
@property (nonatomic, strong) NSMutableArray *orderArr;
@end
