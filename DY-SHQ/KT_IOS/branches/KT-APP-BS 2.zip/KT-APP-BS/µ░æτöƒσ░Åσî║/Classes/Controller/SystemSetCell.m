//
//  SystemSetCell.m
//  民生小区
//
//  Created by 闫青青 on 15/5/12.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "SystemSetCell.h"

@implementation SystemSetCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
