//
//  KTLifeSearchBar.h
//  民生小区
//
//  Created by 罗芳芳 on 15/4/22.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KTLifeSearchBar : UITextField

/**
 *  右边图标的名称
 */
@property (nonatomic, copy) NSString *rightIconName;
@end
