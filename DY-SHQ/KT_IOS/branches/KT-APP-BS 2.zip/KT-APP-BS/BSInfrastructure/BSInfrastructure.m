//
//  BSInfrastructure.m
//  BSInfrastructure
//
//  Created by admin on 15/6/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "BSInfrastructure.h"

@implementation BSInfrastructure

@end
