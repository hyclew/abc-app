//
//  ValidateCode.h
//  民生小区
//
//  Created by 闫青青 on 15/5/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ValidateCode : NSObject

@end
