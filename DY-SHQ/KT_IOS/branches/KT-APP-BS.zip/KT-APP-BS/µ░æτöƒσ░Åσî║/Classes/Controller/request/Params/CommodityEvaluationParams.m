//
//  CommodityEvaluationParams.m
//  民生小区
//
//  Created by 罗芳芳 on 15/5/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import "CommodityEvaluationParams.h"

@implementation CommodityEvaluationParams

@end
