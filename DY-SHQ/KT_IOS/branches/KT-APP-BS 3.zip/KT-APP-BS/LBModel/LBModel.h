//
//  LBModel.h
//  LBModel
//
//  Created by admin on 15/6/6.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LBModel.
FOUNDATION_EXPORT double LBModelVersionNumber;

//! Project version string for LBModel.
FOUNDATION_EXPORT const unsigned char LBModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LBModel/PublicHeader.h>


