//
//  YYHMantleModelSerializer.h
//  YYHModelRouterExample
//
//  Created by Angelo Di Paolo on 11/28/14.
//  Copyright (c) Yayuhh. All rights reserved.
//

#import "YYHModelSerialization.h"

#import <Foundation/Foundation.h>

@interface YYHMantleModelSerializer : NSObject <YYHModelSerialization>

@end
