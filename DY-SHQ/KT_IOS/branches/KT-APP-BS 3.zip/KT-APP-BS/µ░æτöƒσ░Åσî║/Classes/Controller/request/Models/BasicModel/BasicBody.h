//
//  BasicBody.h
//  民生小区
//
//  Created by 罗芳芳 on 15/5/20.
//  Copyright (c) 2015年 itcast. All rights reserved.
//  responseBody 返回内容信息  基类

#import <Foundation/Foundation.h>

@interface BasicBody : NSObject
+ (instancetype)body;

@end
